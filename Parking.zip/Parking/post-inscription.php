<?php 
include 'connexion.php';
//on verifie que le formulaire a bien été envoyé
if (isset($POST['submit'])) {
    
    $Mdp = $_POST['Mdp'];
    $Nom = $_POST['Nom'];
    $Prenom = $_POST['Prenom'];
    $Mail = $_POST['Mail'];
    $verite = false;
    
    //la variable erreur vaut null par défaut
    $erreur = null;
    //on convertit chaque champ en variable avec la fonction extract()
    //extract($_POST);
    //on verifie les champs vides
    if(!empty($Nom) && !empty($Prenom) && !empty($Mail) && !empty($Mdp)){
        $erreur = '<p class = "alert alert-danger"> Veuillez remplir tous les champs</p>';
    }

    $req = $bdd->query('SELECT * FROM utilisateur');
    while ($donnees = $req->fetch()) {
        if ($donnees['nom'] == $nom && $donnees['prenom'] == $prenom) {
            $verite = true;
        }
    }

    $req2 = $bdd->query('SELECT * FROM utilisateur');
    while ($donnees2 = $req2->fetch()) {
        if ($donnees2['nom'] == $nom && $donnees2['prenom'] == $prenom) {
            $verite = false;
        }
    }


    if ($verite == true) {
        $req = $bdd->prepare('INSERT INTO utilisateur(Nom,Prenom,Mail,Mdp) VALUES ( :Nom, :Prenom, :Mail, :Mdp )');
        $req -> execute(array(
        'Nom'=>$Nom,
        'Prenom'=>$Prenom,
        'Mail'=>$Mail,
        'Mdp'=>$Mdp
        ));

        echo 'Vous pouvez dès à présent reserver. <a href="index.php">Retour à l\'accueil</a>';
    } else {
        echo' Le compte est deja existant ou vous n\'etes pas inscrit';
    }
}


?>