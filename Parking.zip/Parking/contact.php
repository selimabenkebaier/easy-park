<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <title> Contact us</title>
</head>
<?php include 'header.php';?>
<body>
<nav>
        <ul class="nav navbar-nav">
            <li><a href="./index.php"title ="home">home </a></li>
            <li><a href="inscription.php" title="inscription"> inscription</a></li>
            <li><a href="connecter.php" title="connexion">connexion</a></li>
            <li class="active"><a href="#" title="contact">contact</a></li>
        </ul>
    
    </nav>

<table>
<form  action="post-contact.php" method="post">
<tr>
    
    <td><label for ="Nom">NOM:</label></td>
    <td><input type ="text" name="Nom"  id="Nom" placeholder="Your Name" required/></td>
</tr>

<tr>
    <td><label for ="Mail">Mail:</label></td>
    <td><input type ="text" name="Mail"  id="Mail" placeholder="Your e-mail" required/></td>
</tr>
<tr>
    <td><label for ="message">Message:</label></td>
    <td><textarea name="message" placeholder="your message" rows="8" cols="45"></textarea>
</tr>
<tr>
    <td><input type="submit" value="Envoyer"/></td>
</tr>

</form>
</table>
</body>

</html>
<?include 'footer.php';?>