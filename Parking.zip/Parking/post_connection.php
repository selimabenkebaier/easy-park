<?php 
//inclusion du fichier de configuration
include 'connexion.php';
























?>