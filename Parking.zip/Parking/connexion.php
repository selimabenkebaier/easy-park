
    <?php 
    $serveur = "localhost";
    $login = "root";
    $pass = "";
//se connecter à une base de données existante déja dans phpmyadmin
    //se connecter à sa base de données test
    //stocker des infos de connexion dans $connexion
    try{

    $connexion = new PDO("mysql:host=$serveur;dbname=parking", $login, $pass);
    $connexion -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     echo 'Connexion à la base de données réussie';
      }

      catch(PDOException $e){
          echo 'Echec de la connexion : ' .$e->getMessage();
      }
    /*dans le cas ou de mauvaise infos de connexion sont envoyées utiliser les exceptions 
 */
    
 ?>
