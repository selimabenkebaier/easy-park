<?php session_start();?>
<!DOCTYPE html>
<html>
       <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
        <link rel="stylesheet" href="./css/style.css" />
    <title>Site de reservation</title>
    
    </head>
    <?php include 'header.php';?>
    <body>
        
    <nav>
        <ul class="nav navbar-nav">
            <li><a href="./index.php"title ="home">home </a></li>
            <li><a href="inscription.php" title="inscription"> inscription</a></li>
            <li class="active"><a href="#" title="connexion">connexion</a></li>
            <li><a href="contact.php" title="contact">contact</a></li>
        </ul>
    
    </nav>
        
        <form method="post" action="post-connection.php">
            <p>
                
                <label>Identifiant</label> : <input type="text" name="identifiant" placeholder="Ex : adresse mail" maxlength="50" /><br /><br />
                <label>Mot de Pass</label> : <input type="Mdp" name="Mdp" maxlength="60" /><br /><br />
                <input type="submit" value=" Je me connecte" /> <a href="mdp-perdu.php">Mot de passe perdu ?</a>
            </p>
        </form>
    </body>
    <?php include'footer.php'; ?>
</html>








