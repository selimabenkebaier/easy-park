<footer>
    <p> copyright &copy; all rights reserved.</p>
</footer>
