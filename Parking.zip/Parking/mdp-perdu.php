<?php session_start();?>

<!DOCTYPE html>
<html>
       <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="moncss.css" />
    <title>Site de reservation</title>
    <h1> MAISON DES LIGUES DE LORRAINE </h1>
    </head>

    <?php include 'menu.php';
    include 'connexion.php' ?>
    <body>
        <h2> Mot de passe oublié ?</h2>
        <form method="post" action="mdp-perdu.php">
            <p>
                <h3> Entrez vos coordonnées</h3><br />
                <label>Votre Adresse Mail</label> : <input type="mail" name="Mail" placeholder="Ex : dupont.pierre@gmail.com" maxlength="50" /><br /><br />
                <label>Nouveau mot de passe</label> : <input type="Mdp" name="Mdp" maxlength="60" /><br /><br />
                <input type="submit" value="Valider" />
            </p>
        </form>
        <?php 
		$Mail = $_POST['Mail'];
		$Mdp = $_POST['Mdp']; 
		$trouve = false;

		$req = $bdd->query('SELECT * FROM utilisateur');
		while($donnees = $req->fetch())
		{
			if($donnees['Mail'] == $Mail )
			{
				$req2 = $bdd->prepare('UPDATE utilisateur SET mdp = :mdp WHERE Mail = :Mail ');
				$req2->execute(array(
					'Mail'=> $Mail,
					'Mdp'=> $Mdp));

				$trouve = true;

				echo 'Le mot de passe a été changé. <a href="connecter.php">Retour à la page de connexion</a>';
			}
		}

		if($trouve == false)
		{
			echo'Erreur de saisie.<a href="mdp-perdu.php">Resaisir</a>ou <a href="index.php">Retour à la page d\'accueil</a>';
		}

		?>
    </body>
    <?php include("footer.php"); ?>
</html>